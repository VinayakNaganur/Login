package com.kindsonthegenius.product_app.services;

import com.kindsonthegenius.product_app.model.User;
import com.kindsonthegenius.product_app.repositories.UserRepository;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    public boolean authenticate(String username, String password) {
        User user = userRepository.findByUsername(username);
        if(user == null){
            throw new UsernameNotFoundException("User does not exist in the database");
        }
        if (!password.equals(user.getPassword())) {
            throw  new BadCredentialsException("The password is incorrect");
        }
        return  true;
    }
    public User register(User user) {
        // Store password as plain text (not recommended for production)
        return userRepository.save(user);
    }
}
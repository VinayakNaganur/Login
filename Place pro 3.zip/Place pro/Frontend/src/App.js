import './App.css';
import ButtonAppBar from './components/Appbar';

import { BrowserRouter, Route, Routes, useLocation, Navigate } from 'react-router-dom';

import Registration from './components/Registration';
import RegistrationSuccess from './components/RegistrationSuccess';
import Login from './components/Login';
import { AuthProvider, useAuth } from './components/AuthContext';
import ProtectedContent from './components/ProtectedContent';

const PrivateRoute = ({ children }) => {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? children : <Navigate to="/login" />;
};

const Layout = () => {
  const location = useLocation();
  const noNavRoutes = ['/', '/registration', '/login'];

  return (
    <>
      {!noNavRoutes.includes(location.pathname) && <ButtonAppBar />}
      <Routes>
        <Route path='/registration' element={<Registration />} />
        <Route path='/registrationSuccess' element={<RegistrationSuccess />} />
        <Route path='/' element={<Login />} />
        <Route path='/login' element={<Login />} />
        <Route path='/content' element={
          <PrivateRoute>
            <ProtectedContent />
          </PrivateRoute>
        } />
      </Routes>
    </>
  );
};

function App() {
  return (
    <div className="App">
      <AuthProvider>
        <BrowserRouter>
          <Layout />
        </BrowserRouter>
      </AuthProvider>
    </div>
  );
}

export default App;

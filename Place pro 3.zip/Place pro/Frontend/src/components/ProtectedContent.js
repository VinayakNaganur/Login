import React, { useState, useEffect } from 'react';
import { Typography, Container, Box, CircularProgress, Alert, Card, CardContent, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, TextField, MenuItem, InputAdornment, IconButton } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';

const getAllColumns = (data) => {
  const columns = new Set();
  Object.values(data).forEach(item => {
    if (typeof item === 'object' && item !== null) {
      Object.keys(item).forEach(key => columns.add(key));
    }
  });
  return Array.from(columns);
};

const getAllUserTypes = (data) => {
  const userTypes = new Set();
  Object.values(data).forEach(item => {
    if (item && item.userType) userTypes.add(item.userType);
  });
  return Array.from(userTypes);
};

export default function ProtectedContent() {
  const [content, setContent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [userTypeFilter, setUserTypeFilter] = useState('');

  useEffect(() => {
    const fetchContent = async () => {
      console.log('Attempting to fetch content.json from public folder...');
      try {
        setLoading(true);
        const response = await fetch('/content.json');
        if (!response.ok) throw new Error('Network response was not ok');
        const data = await response.json();
        setContent(data);
        setError('');
        console.log('Successfully fetched content from content.json:', data);
      } catch (err) {
        setError('Failed to fetch content.json.');
        setContent(null);
        console.error('Failed to fetch content.json:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchContent();
  }, []);

  const columns = content ? getAllColumns(content) : [];
  const userTypes = content ? getAllUserTypes(content) : [];

  const filterRows = (data) => {
    if (!data) return [];
    return Object.entries(data).filter(([stage, details]) => {
      const matchesSearch =
        stage.toLowerCase().includes(search.toLowerCase()) ||
        columns.some(col =>
          details[col] && details[col].toString().toLowerCase().includes(search.toLowerCase())
        );
      const matchesUserType = userTypeFilter ? details.userType === userTypeFilter : true;
      return matchesSearch && matchesUserType;
    });
  };

  const filteredRows = filterRows(content);

  const renderTable = () => {
    if (!content || typeof content !== 'object') {
      // Pretty JSON fallback
      return (
        <Box sx={{
          background: 'linear-gradient(90deg, #e0eafc 0%, #cfdef3 100%)',
          borderRadius: 3,
          p: 3,
          mt: 2,
          fontFamily: 'Fira Mono, monospace',
          fontSize: 16,
          color: '#283e51',
          overflowX: 'auto',
          boxShadow: 2
        }}>
          <Typography variant="h6" sx={{ mb: 1, fontWeight: 700 }}>Raw JSON Data</Typography>
          <pre style={{ margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>{JSON.stringify(content, null, 2)}</pre>
        </Box>
      );
    }
    return (
      <TableContainer component={Paper} sx={{ mt: 2, borderRadius: 3, boxShadow: 3 }}>
        <Table>
          <TableHead sx={{ background: 'linear-gradient(90deg, #e0eafc 0%, #cfdef3 100%)' }}>
            <TableRow>
              <TableCell><b>Stage/Action</b></TableCell>
              {columns.map(col => (
                <TableCell key={col}><b>{col}</b></TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredRows.map(([stage, details]) => (
              <TableRow key={stage}>
                <TableCell sx={{ fontWeight: 600 }}>{stage}</TableCell>
                {columns.map(col => (
                  <TableCell key={col}>
                    {Array.isArray(details?.[col])
                      ? details[col].join(', ')
                      : details?.[col] ?? ''}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    );
  };

  return (
    <Container maxWidth="xl">
      <Box sx={{ mt: 4 }}>
        <Card sx={{ borderRadius: 4, boxShadow: 4 }}>
          
          <CardContent>
            <Box sx={{ display: 'flex', gap: 2, mb: 2, flexWrap: 'wrap', alignItems: 'center' }}>
              <TextField
                label="Search"
                variant="outlined"
                size="small"
                value={search}
                onChange={e => setSearch(e.target.value)}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton>
                        <SearchIcon />
                      </IconButton>
                    </InputAdornment>
                  )
                }}
                sx={{ minWidth: 220 }}
              />
              <TextField
                select
                label="Filter by User Type"
                value={userTypeFilter}
                onChange={e => setUserTypeFilter(e.target.value)}
                size="small"
                variant="outlined"
                sx={{ minWidth: 220 }}
              >
                <MenuItem value="">All</MenuItem>
                {userTypes.map(type => (
                  <MenuItem key={type} value={type}>{type}</MenuItem>
                ))}
              </TextField>
            </Box>
            {loading && <CircularProgress />}
            {error && <Alert severity="error">{error}</Alert>}
            {!loading && !error && renderTable()}
          </CardContent>
        </Card>
      </Box>
    </Container>
  );
} 
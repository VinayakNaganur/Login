import React, { useState } from 'react'
import {
    Typography,
    Button,
    Box,
    Container,
    Card,
    CardActions,
    CardHeader,
    CardContent,
    TextField
  } from '@mui/material';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from './AuthContext';

export default function Login() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate()
    const {login} = useAuth();

    const handleLogin = async (e) => {
        e.preventDefault()
        setError('')
        console.log('Login attempt started...');
        const loginData = { username, password }
        try {
            console.log('Sending login credentials to the backend:', loginData);
            const response = await axios.post('http://localhost:8080/login', loginData);
            console.log('Received response from backend:', response);
            if (response.status >= 200 && response.status < 300 && response.data.token){
                localStorage.setItem('jwtToken', response.data.token);
                console.log('Successfully received and stored JWT token from backend.');
                login();
                navigate('/content')
            } else {
                setError('Login failed for user. Please retry!')
                console.error('Login failed: Response from backend did not include a token or had an unsuccessful status.', response);
            }
        } catch(error) {
            setError('An error occurred. Please retry')
            console.error('An error occurred during login:', error);
        }
    }

  return (
    <Box sx={{ minHeight: '100vh', background: 'linear-gradient(120deg, #e0eafc 0%, #cfdef3 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Container maxWidth="sm">
        <Card sx={{ borderRadius: 5, boxShadow: 6, p: 2, background: 'rgba(255,255,255,0.95)' }}>
          <CardHeader
            title={<Typography variant="h4" align="center" sx={{ fontWeight: 700, letterSpacing: 2, color: '#283e51' }}>Login</Typography>}
            sx={{ pb: 0, background: 'linear-gradient(90deg, #e0eafc 0%, #cfdef3 100%)', borderTopLeftRadius: 20, borderTopRightRadius: 20 }}
          />
          <CardContent>
            <Box
              component="form"
              onSubmit={handleLogin}
              sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 3 }}
            >
              {error && (
                <Typography variant="body2" color="error" align="center">
                  {error}
                </Typography>
              )}
              <TextField
                label="Username"
                variant="outlined"
                fullWidth
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                sx={{ background: '#f7fafc', borderRadius: 2 }}
              />
              <TextField
                label="Password"
                variant="outlined"
                type="password"
                fullWidth
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                sx={{ background: '#f7fafc', borderRadius: 2 }}
              />
              <Button type="submit" variant="contained" size="large" sx={{
                background: 'linear-gradient(90deg, #283e51 0%, #485563 100%)',
                color: '#fff',
                fontWeight: 700,
                borderRadius: 2,
                boxShadow: 2,
                py: 1.5,
                '&:hover': {
                  background: '#fff',
                  color: '#283e51',
                  border: '1px solid #283e51',
                },
              }}>
                Login
              </Button>
            </Box>
          </CardContent>
          <CardActions sx={{ justifyContent: 'center', pb: 2 }}>
            <Link to="/registration" style={{ textDecoration: 'none' }}>
              <Button variant="text" color="primary" sx={{ fontWeight: 600 }}>
                Don't have an account? Sign up
              </Button>
            </Link>
          </CardActions>
        </Card>
      </Container>
    </Box>
  )
}

import axios from 'axios'
import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import {
    Typography,
    Button,
    Box,
    Container,
    Grid,
    TextField,
    Card,
    CardHeader,
    CardContent
  } from '@mui/material';

export default function Registration() {

    const [formData, setFormData] = useState({
        firstname: '',
        lastname: '',
        username: '',
        password: '',
        confirmPassword: ''
    })

    const [error, setError] = useState('')
    const navigate = useNavigate()

    const [passwordChecks, setPasswordChecks] = useState({
        length: false,
        capital: false,
        number: false
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
        if (name === 'password') {
            setPasswordChecks({
                length: value.length >= 7,
                capital: /[A-Z]/.test(value),
                number: /[0-9]/.test(value)
            });
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log('Registration attempt started...');

        // Username validation
        if (formData.username.length < 7) {
            setError('Username must be at least 7 characters long.');
            return;
        }

        // Password validation
        const password = formData.password;
        if (password.length < 7) {
            setError('Password must be at least 7 characters long.');
            return;
        }
        if (!/[A-Z]/.test(password)) {
            setError('Password must contain at least one uppercase letter.');
            return;
        }
        if (!/[0-9]/.test(password)) {
            setError('Password must contain at least one number.');
            return;
        }

        if (formData.password !== formData.confirmPassword) {
            setError('Passwords do not match');
            console.warn('Registration failed: Passwords do not match.');
            return;
        }
        setError('')

        try {
            console.log('Sending registration data to the backend:', formData);
            const response = await axios.post('http://localhost:8080/register', formData);
            console.log('Received response from backend:', response);

            if(response.status === 201 || response.status === 200) {
                console.log('Registration successful. Redirecting to login.');
                localStorage.setItem('isRegistered', 'true');
                alert('Registration successful! Please login.');
                navigate('/login')
            } else {
                setError('Registration failed. Please try again.')
                console.error('Registration failed: Unsuccessful response from backend.', response);
            }
        } catch(err) {
            setError('An error occurred during user registration')
            console.error('An error occurred during registration:', err);
        }
    }

  return (
    <Box sx={{ minHeight: '100vh', background: 'linear-gradient(120deg, #e0eafc 0%, #cfdef3 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Container maxWidth="sm">
        <Card sx={{ borderRadius: 5, boxShadow: 6, p: 2, background: 'rgba(255,255,255,0.95)' }}>
          <CardHeader
            title={<Typography variant="h4" align="center" sx={{ fontWeight: 700, letterSpacing: 2, color: '#283e51' }}>Register</Typography>}
            sx={{ pb: 0, background: 'linear-gradient(90deg, #e0eafc 0%, #cfdef3 100%)', borderTopLeftRadius: 20, borderTopRightRadius: 20 }}
          />
          <CardContent>
            <Box sx={{ mt: 2 }}>
              <form onSubmit={handleSubmit}>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      label="First Name"
                      name="firstname"
                      fullWidth
                      value={formData.firstname}
                      onChange={handleChange}
                      required
                      sx={{ background: '#f7fafc', borderRadius: 2 }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      label="Last Name"
                      name="lastname"
                      fullWidth
                      value={formData.lastname}
                      onChange={handleChange}
                      required
                      sx={{ background: '#f7fafc', borderRadius: 2 }}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      label="Username"
                      name="username"
                      fullWidth
                      value={formData.username}
                      onChange={handleChange}
                      required
                      sx={{ background: '#f7fafc', borderRadius: 2 }}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      label="Password"
                      name="password"
                      type="password"
                      fullWidth
                      value={formData.password}
                      onChange={handleChange}
                      required
                      sx={{ background: '#f7fafc', borderRadius: 2 }}
                    />
                    <Box sx={{ mt: 1, ml: 1 }}>
                      <Typography variant="caption" sx={{ color: passwordChecks.length ? 'green' : 'red', display: 'block' }}>
                        • At least 7 characters
                      </Typography>
                      <Typography variant="caption" sx={{ color: passwordChecks.capital ? 'green' : 'red', display: 'block' }}>
                        • At least one uppercase letter
                      </Typography>
                      <Typography variant="caption" sx={{ color: passwordChecks.number ? 'green' : 'red', display: 'block' }}>
                        • At least one number
                      </Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      label="Confirm Password"
                      name="confirmPassword"
                      type="password"
                      fullWidth
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      required
                      sx={{ background: '#f7fafc', borderRadius: 2 }}
                    />
                  </Grid>
                  {error && (
                    <Grid item xs={12}>
                      <Typography color="error" variant="body2" align="center">
                        {error}
                      </Typography>
                    </Grid>
                  )}
                  <Grid item xs={12}>
                    <Button type="submit" fullWidth variant="contained" size="large" sx={{
                      background: 'linear-gradient(90deg, #283e51 0%, #485563 100%)',
                      color: '#fff',
                      fontWeight: 700,
                      borderRadius: 2,
                      boxShadow: 2,
                      py: 1.5,
                      '&:hover': {
                        background: '#fff',
                        color: '#283e51',
                        border: '1px solid #283e51',
                      },
                    }}>
                      Register
                    </Button>
                  </Grid>
                  <Grid item xs={12} sx={{ textAlign: 'center' }}>
                    <Link to="/login" style={{ textDecoration: 'none' }}>
                      <Button variant="text" color="primary" sx={{ fontWeight: 600 }}>
                        Back to Login
                      </Button>
                    </Link>
                  </Grid>
                </Grid>
              </form>
            </Box>
          </CardContent>
        </Card>
      </Container>
    </Box>
  )
}

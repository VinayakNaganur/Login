import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { useAuth } from './AuthContext';
import { useNavigate } from 'react-router-dom';

export default function ButtonAppBar() {
  const { logout } = useAuth();
  const navigate = useNavigate();

  const logoutUser = () => {
    logout();
    navigate("/login");
  };

  const isRegistered = localStorage.getItem('isRegistered') === 'true';

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static" sx={{ background: 'linear-gradient(90deg, #283e51 0%, #485563 100%)', boxShadow: 3, py: 1 }}>
        <Toolbar sx={{ minHeight: 64, px: 2 }}>
          <Typography variant="h5" component="div" sx={{ flexGrow: 1, fontWeight: 700, letterSpacing: 2 }}>
            Products List
          </Typography>
          {!isRegistered && (
            <Button
              href="/registration"
              variant="outlined"
              color="secondary"
              sx={{
                ml: 2,
                borderRadius: 2,
                borderColor: '#fff',
                color: '#fff',
                fontWeight: 600,
                '&:hover': {
                  backgroundColor: '#fff',
                  color: '#283e51',
                  borderColor: '#283e51',
                },
              }}
            >
              REGISTER
            </Button>
          )}
          <Button
            onClick={logoutUser}
            color="inherit"
            variant="contained"
            sx={{
              ml: 2,
              background: 'linear-gradient(90deg, #485563 0%, #283e51 100%)',
              color: '#fff',
              fontWeight: 600,
              borderRadius: 2,
              boxShadow: 2,
              '&:hover': {
                background: '#fff',
                color: '#283e51',
              },
            }}
          >
            Logout
          </Button>
        </Toolbar>
      </AppBar>
    </Box>
  );
}
